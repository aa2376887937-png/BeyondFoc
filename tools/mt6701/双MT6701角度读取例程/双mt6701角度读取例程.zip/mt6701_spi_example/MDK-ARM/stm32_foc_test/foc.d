stm32_foc_test/foc.o: ..\Drivers\motor\foc.c ..\Drivers\motor\foc.h \
  ..\Middlewares\ST\ARM\DSP\Inc\arm_math.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  ..\Drivers\motor\motor_runtime_param.h ..\Drivers\motor\conf.h \
  ..\Core\Inc\global_def.h
